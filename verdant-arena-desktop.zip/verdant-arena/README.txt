Verdant Arena - Desktop Edition

Requirements: Python 3.10 or newer and an internet connection for the first install.

Windows:
  py -m pip install -r requirements.txt
  py mian.py

macOS / Linux:
  python3 -m pip install -r requirements.txt
  python3 mian.py

Run these commands from the extracted verdant-arena folder. A desktop window
will open. Use WASD or arrow keys to move, Space or click to strike, and Esc
to quit.
